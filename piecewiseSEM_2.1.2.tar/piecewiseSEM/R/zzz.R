.onAttach <- function(libname, pkgname) {

  packageStartupMessage("
  This is piecewiseSEM version 2.1.0.\n

  Questions or bugs can be addressed to <LefcheckJ@si.edu>.")
  
  }
